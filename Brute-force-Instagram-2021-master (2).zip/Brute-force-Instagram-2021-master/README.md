# Brute-force-Instagram-2021 - under maintenance now!



[![Version](https://img.shields.io/badge/Brutesploit-1.1.0-brightgreen.svg?maxAge=259200)]()
[![Version](https://img.shields.io/badge/Codename-Pretty-red.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Linux-orange.svg)]()

Instagram brute force working in new format 2021, proxy added ^-* , open source, you can modify it

## Legal disclaimer:

Usage of insTof for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

![tweet](https://steamuserimages-a.akamaihd.net/ugc/943951547336911675/8FC1DADCBAF77B83508E1E203373F3EEFF9D7DF9/)

### A look at the tool
 
 
 <img src="https://k.top4top.io/p_1994btxsh1.jpeg" width="30%"></img>
 <img src="https://l.top4top.io/p_1994kwpq92.jpeg" width="30%"></img>



## Getting Started
1. ```git clone https://github.com/0xfff0800/Brute-force-Instagram-2021.git```
2. ```pip3 install colorama```
3. ```cd Brute-force-Instagram-2021```
4. ```python3 insTof6.py```


## A Kali Linux operating system. We recommend :
- Kali Linux 2 or Kali 2016.1 rolling 
- Cyborg
- Parrot 
- BackTrack 
- Backbox  
- Android - Trimix
- Iphone - python ai 

## BUG ? 
- Please Submit new issue 
- Contact me
- Hey ? do you want ask about all my tools ? you can join me in [Telegram](https://T.me/flaah999)

## Donations 

 <img src="https://www.up-00.com/i/00176/4gu5yi4fwmgt.jpg" width="30%"></img>
 
 ## Download and Clone
 > Download: Click [Here](https://github.com/0xfff0800/Brute-force-Instagram-2020/archive/master.zip) (Brute-force-Instagram-2021.zip)
 
